//
//  HeaderViewController.swift
//  PelhamiOSApp
//
//  Created by IBLEMAC LAP on 28/07/21.
//  Copyright © 2021 IBLEOSFT. All rights reserved.
//

import UIKit
@available(iOS 13.0, *)
class HeaderViewController: UIViewController {
    
    var naviFrom = ""

    @IBOutlet weak var homeBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        print(naviFrom)

    }
    
    // MARK:- Button Actions
    @IBAction func backAction(_ sender: Any) {
        
            let vc = self.storyboard?.instantiateViewController(identifier: "ViewController") as! ViewController
            navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func homeAction(_ sender: Any) {
       
        let vc = self.storyboard?.instantiateViewController(identifier: "ViewController") as! ViewController
        navigationController?.pushViewController(vc, animated: true)
    }

}
