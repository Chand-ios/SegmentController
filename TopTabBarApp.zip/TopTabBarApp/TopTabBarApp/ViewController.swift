//
//  ViewController.swift
//  TopTabBarApp
//
//  Created by iblesoft on 17/06/22.
//

import UIKit
import SJSegmentedScrollView
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func tapAction(_ sender: Any) {
        navigation()
    }
    

    //MARK: - Paging View Controller Methods.
    @objc func navigation(){
        if let storyboard = self.storyboard {

            let headerViewController = storyboard
                .instantiateViewController(withIdentifier: "HeaderViewController") as! HeaderViewController

            let firstViewController = storyboard
                .instantiateViewController(withIdentifier: "FirstViewController") as! FirstViewController
            firstViewController.title = "First Tab"

            let secondViewController = storyboard
                .instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
            secondViewController.title = "Second Tab"

            let segmentController = SJSegmentedViewController()
            segmentController.headerViewController = headerViewController
            segmentController.segmentControllers = [firstViewController,secondViewController]
            segmentController.headerViewHeight = 100.0
            segmentController.headerViewOffsetHeight = 100
           // segmentController.headerViewOffsetHeight = 200.0
           // segmentController.segmentTitleColor = UIColor(red: 76.0/255.0, green: 175.0/255.0, blue: 80.0/255.0, alpha: 1)
            segmentController.segmentSelectedTitleColor = UIColor(red: 76.0/255.0, green: 175.0/255.0, blue: 80.0/255.0, alpha: 1)
            navigationController?.pushViewController(segmentController, animated: true)
    }
        
    }
}

